/*@__MAKEUP_API_START__*/
'use strict';

const studio = require('./studio.js');

Object.assign(globalThis, studio.m);
/* Feel free to add your custom code below */

/*@__MAKEUP_API_END__*//*@__GLTF_ANIMATION_START__*/
const gltf_Beads04 = bnb.scene.getRoot().findChildByName('Beads04')?.getComponent(bnb.ComponentType.MESH_INSTANCE)?.asMeshInstance();

    gltf_Beads04?.animationPlay();

/*@__GLTF_ANIMATION_END__*/