/*@__MAKEUP_API_START__*/
'use strict';

const studio = require('./studio.js');

Object.assign(globalThis, studio.m);
/* Feel free to add your custom code below */

/*@__MAKEUP_API_END__*//*@__GLTF_ANIMATION_START__*/
const gltf_Heart = bnb.scene.getRoot().findChildByName('Heart')?.getComponent(bnb.ComponentType.MESH_INSTANCE)?.asMeshInstance();

    gltf_Heart?.animationPlay();

/*@__GLTF_ANIMATION_END__*/