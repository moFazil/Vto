/*@__MAKEUP_API_START__*/
'use strict';

const studio = require('./studio.js');

Object.assign(globalThis, studio.m);
/* Feel free to add your custom code below */

/*@__MAKEUP_API_END__*//*@__GLTF_ANIMATION_START__*/
const gltf_EARRR = bnb.scene.getRoot().findChildByName('EARRR')?.getComponent(bnb.ComponentType.MESH_INSTANCE)?.asMeshInstance();

    gltf_EARRR?.animationPlay();
const gltf_EARRR1 = bnb.scene.getRoot().findChildByName('EARRR1')?.getComponent(bnb.ComponentType.MESH_INSTANCE)?.asMeshInstance();

    gltf_EARRR1?.animationPlay();

/*@__GLTF_ANIMATION_END__*/