'use strict';

require('bnb_js/global');
const modules_scene_index = require('../scene/index.js');

const fragmentShader = "modules/camera-shader/camera_shader.frag";

const vertexShader = "modules/camera-shader/camera_shader.vert";

class CameraShader {
    constructor() {
        Object.defineProperty(this, "_shader", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new modules_scene_index.Mesh(new modules_scene_index.PlaneGeometry(), new modules_scene_index.ShaderMaterial({
                vertexShader,
                fragmentShader,
                uniforms: {
                    tex_camera: new modules_scene_index.Scene()
                }
            }))
        });
        modules_scene_index.add(this._shader);
    }
}

exports.CameraShader = CameraShader;
