'use strict';

require('bnb_js/global');
const modules_scene_index = require('../scene/index.js');

const fragmentShader = "modules/foreground/foreground.frag";

const vertexShader = "modules/foreground/foreground.vert";

var BlendMode;
(function (BlendMode) {
    /* 0 */ BlendMode[BlendMode["NORMAL"] = 0] = "NORMAL";
    /* 1 */ BlendMode[BlendMode["MULTIPLY"] = 1] = "MULTIPLY";
    /* 2 */ BlendMode[BlendMode["SCREEN"] = 2] = "SCREEN";
    /* 3 */ BlendMode[BlendMode["OVERLAY"] = 3] = "OVERLAY";
    /* 4 */ BlendMode[BlendMode["SOFT_LIGHT"] = 4] = "SOFT_LIGHT";
    /* 5 */ BlendMode[BlendMode["HARD_LIGHT"] = 5] = "HARD_LIGHT";
})(BlendMode || (BlendMode = {}));
class Foreground {
    constructor() {
        Object.defineProperty(this, "_foreground", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new modules_scene_index.Mesh(new modules_scene_index.PlaneGeometry(), new modules_scene_index.ShaderMaterial({
                vertexShader,
                fragmentShader,
                uniforms: {
                    tex_camera: new modules_scene_index.Scene(),
                    tex_foreground: new modules_scene_index.Image(),
                    var_foreground_mode_width_height: new modules_scene_index.Vector4(BlendMode.NORMAL, 0, 0),
                },
            }))
        });
        modules_scene_index.add(this._foreground);
        // The texture may already has an image if the texture was created by deserializer
        const isVisible = Boolean(this._foreground.material.uniforms.tex_foreground.width &&
            this._foreground.material.uniforms.tex_foreground.height);
        this._foreground.visible(isVisible);
    }
    /**
     * Sets the Foreground texture
     *
     * Pass empty string "" to clear the texture
     */
    texture(filename) {
        this._foreground.material.uniforms.tex_foreground.load(filename, () => {
            const { tex_foreground, var_foreground_mode_width_height } = this._foreground.material.uniforms;
            var_foreground_mode_width_height.y(tex_foreground.width);
            var_foreground_mode_width_height.z(tex_foreground.height);
        });
        this._foreground.visible(Boolean(filename));
    }
    /**
     * Sets the blend mode
     */
    blendMode(mode) {
        if (typeof mode !== "undefined") {
            this._foreground.material.uniforms.var_foreground_mode_width_height.x(BlendMode[mode.toUpperCase()]);
        }
        const value = this._foreground.material.uniforms.var_foreground_mode_width_height.x();
        return BlendMode[value].toLowerCase();
    }
    /** Resets all the settings applied */
    clear() {
        this.texture("");
        this.blendMode("normal");
    }
}

exports.Foreground = Foreground;
